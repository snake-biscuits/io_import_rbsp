from __future__ import annotations
import collections
from typing import Dict, List, Union

from .. import geometry
from . import base

import breki
from breki.files.parsed import parse_first


GroupList = Union[
    List[geometry.Model],
    Dict[str, base.ModelList]]


class Obj(base.SceneDescription, breki.FriendlyTextFile):
    """Y+ forward; Z+ up"""
    exts = ["*.obj"]
    groups: Dict[str, Dict[str, geometry.Model]]
    # ^ {"group_name": {"model_name": model}}
    mtl_files: List[str]

    def __init__(self, filepath: str, archive=None, code_page=None):
        super().__init__(filepath, archive, code_page)
        self.groups = dict()
        self.mtl_files = list()

    @parse_first
    def __repr__(self) -> str:
        num_models = sum(len(ms) for ms in self.groups.values())
        descriptor = " ".join([
            f'"{self.filename}"',
            f"{len(self.groups)} groups",
            f"{num_models} models"])
        return f"<{self.__class__.__name__} {descriptor} @ 0x{id(self):016X}>"

    @parse_first
    def as_lines(self) -> List[str]:
        out = list()
        out.append("# generated w/ ass")

        def indices(polygon: geometry.Polygon) -> List[int]:
            """rexx magic obj indexing; works for Blender, might break elsewhere"""
            # NOTE: inverts winding order; which is desired
            return range(-1, -(len(polygon.vertices) + 1), -1)

        # TODO: make sure None group is first
        for group_name, models in self.groups.items():
            if group_name is not None:
                out.append(f"g {group_name}")
            for model_name, model in models.items():
                if model_name is not None:
                    out.append(f"o {model_name}")
                polygons = collections.defaultdict(list)
                # ^ {Material: [Polygon]}
                for mesh in model.meshes:
                    polygons[mesh.material].extend(mesh.polygons)
                for material in polygons:
                    out.append(f"usemtl {material.name}")
                    # TODO: generate .mtl files
                    # -- f"mtllib {material.name}.mtl"
                    for polygon in polygons[material]:
                        vertices = [*map(model.apply_transforms, polygon.vertices)]
                        # NOTE: only the first uv can be saved
                        if all(len(v.uv) > 0 for v in vertices):
                            for v in vertices:
                                out.extend([
                                    f"v {v.position.x} {v.position.y} {v.position.z}",
                                    f"vn {v.normal.x} {v.normal.y} {v.normal.z}",
                                    f"vt {v.uv[0].x} {v.uv[0].y}"])
                            out.append("f " + " ".join([
                                f"{i}/{i}/{i}" for i in indices(polygon)]))
                        else:  # no uv
                            for v in vertices:
                                out.extend([
                                    f"v {v.position.x} {v.position.y} {v.position.z}",
                                    f"vn {v.normal.x} {v.normal.y} {v.normal.z}"])
                            out.append("f " + " ".join([
                                f"{i}//{i}" for i in indices(polygon)]))
        return out

    @property
    def friend_patterns(self) -> Dict[str, breki.DataType]:
        return {
            filename: breki.DataType.TEXT
            for filename in self.mtl_files}

    def parse(self):
        if self.is_parsed:
            return
        self.is_parsed = True
        # parser state
        groups = {None: {None: geometry.Model([geometry.Mesh()])}}
        group_name = None
        model_name = None
        vs = [(0, 0, 0)]
        vns = [(0, 0, 0)]
        vts = [(0, 0)]
        # parse line by line
        for line in self.stream:
            line = line.strip()
            type_, args = line.partition(" ")[::2]
            if type_ == "g":
                group_name = args
                model_name = None
                groups[group_name] = dict()
                groups[group_name][model_name] = geometry.Model([geometry.Mesh()])
            elif type_ == "o":
                model_name = args
                groups[group_name][model_name] = geometry.Model([geometry.Mesh()])
            elif type_ == "v":
                vs.append(tuple(map(float, args.split(" "))))
            elif type_ == "vn":
                vns.append(tuple(map(float, args.split(" "))))
            elif type_ == "vt":
                vts.append(tuple(map(float, args.split(" "))))
            elif type_ == "f":
                face = list()
                for point in args.split(" "):
                    vi, vni, vti = 0, 0, 0
                    if "/" not in point:  # "vi"
                        vi = int(point)
                    elif "//" in point:  # "vi//vni"
                        vi, vni = map(int, point.split("//"))
                    elif point.count("/") == 2:  # "vi/vti/vni"
                        vi, vti, vni = map(int, point.split("/"))
                    elif point.count("/") == 1:  # "vi/vti"
                        vi, vti = map(int, point.split("/"))
                    else:
                        raise RuntimeError(f"could not parse point: '{point}'")
                    face.append(geometry.Vertex(vs[vi], vns[vni], vts[vti]))
                groups[group_name][model_name].meshes[-1].polygons.append(
                    geometry.Polygon(face))
            elif type_ == "mtllib":
                self.mtl_files.append(args)
            elif type_ == "usemtl":
                material = geometry.Material(args)
                mesh = geometry.Mesh(material)
                groups[group_name][model_name].meshes.append(mesh)
        # cleanup
        clean = dict()
        # remove empty meshes
        for group_name, group in groups.items():
            clean[group_name] = dict()
            for model_name, model in group.items():
                meshes = [
                    mesh
                    for mesh in model.meshes
                    if len(mesh.polygons) > 0]
                if len(meshes) > 0:
                    clean[group_name][model_name] = geometry.Model(meshes)
        # remove empty groups
        clean = {
            group_name: group
            for group_name, group in clean.items()
            if len(group) > 0}
        # all done
        self.groups = clean
        self.make_friends()  # .mtl files

    @classmethod
    def from_groups(cls, filepath: str, groups: GroupList) -> Obj:
        out = cls(filepath)
        if isinstance(groups, (list, tuple, set)):
            groups = {
                f"group_{i:03d}": group
                for i, group in enumerate(groups)}
        assert isinstance(groups, dict), "'groups' must be a GroupList!"
        out.groups = groups
        out.is_parsed = True
        return out

    @classmethod
    def from_models(cls, filepath: str, models: base.ModelList) -> Obj:
        if isinstance(models, (list, tuple, set)):
            models = {
                f"model_{i:03d}": model
                for i, model in enumerate(models)}
        assert isinstance(models, dict), "'models' must be a ModelList!"
        return cls.from_groups(filepath, {"group_000": models})
