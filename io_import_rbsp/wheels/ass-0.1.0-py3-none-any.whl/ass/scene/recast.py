"""for r2recast .nm files (Titanfall 2 NPC Navigation Meshes)"""
from __future__ import annotations
import io
import struct
from typing import Dict, List, Tuple

from .. import geometry
from .. import vector
from . import base

import breki
from breki import binary
from breki import core
from breki.files.parsed import parse_first


class Params(core.MappedArray):
    _format = "5f5i"
    _mapping = {
        "origin": [*"xyz"],
        "tile_size": ["width", "height"],
        "max_tiles": None,
        "max_polygons": None,
        # "i hate this"
        "disjoint_polygon_group_count": None,
        "reachability_table": ["size", "count"]}
    _classes = {
        "origin": vector.vec3}


class FileHeader(core.Struct):
    magic: bytes  # b"TESM" (M SET)
    version: int  # 5
    num_tiles: int
    params: Params

    _format = "4s2I" + Params._format
    __slots__ = ["magic", "version", "num_tiles", "params"]
    _arrays = {"params": Params._mapping}
    _classes = {"params": Params}


TilePos = Tuple[int, int, int]  # ivec3
# ^ (x, y, layer)


class TileHeader(core.Struct):  # dtMeshHeader
    """Detour/Include/DetourNavMesh.h:274"""
    magic: bytes  # b"VAND" (D NAV)
    version: int  # 13
    position: TilePos
    user_id: int
    num_polygons: int
    per_poly_size: int  # bonus data
    num_vertices: int
    num_links: int
    detail: List[int]
    num_bounds_nodes: int
    num_connections: int  # number of off-mesh connections
    first_connection: int  # index of first polygon w/ off-mesh connection
    agent: List[int]  # walkable agent restrictions
    bounds: Tuple[vector.vec3, vector.vec3, float]

    _format = "4s4iI10i10f"
    __slots__ = [
        "magic", "version", "position", "user_id",
        "num_polygons", "per_poly_size", "num_vertices", "num_links",
        "detail", "num_bounds_nodes",
        "num_connections", "first_connection",
        "agent", "bounds"]
    _arrays = {
        "position": ["x", "y", "layer"],
        "detail": ["num_meshes", "num_vertices", "num_triangles"],
        "agent": ["height", "radius", "climb_height"],
        "bounds": {
            "mins": [*"xyz"],
            "maxs": [*"xyz"],
            "quantization_factor": None}}
    _classes = {
        "bounds.mins": vector.vec3,
        "bounds.maxs": vector.vec3}


class Polygon(core.Struct):  # dtPoly
    """r2recast/Detour/Include/DetourNavMesh.h:158"""
    first_link: int
    indices: List[int]  # 6x vertex indices
    neighbours:  List[int]  # 6x neighbour edge indices
    flags: int
    num_vertices: int
    area_type: int  # 6:2 bitfield
    disjoint_set_id: int
    unknown: int
    center: vector.vec3

    _format = "I13H2B2H3f"
    __slots__ = [
        "first_link", "indices", "neighbours", "flags",
        "num_vertices", "area_type", "disjoint_set_id",
        "unknown", "center"]
    _arrays = {
        "indices": 6, "neighbours": 6,
        "center": [*"xyz"]}
    _classes = {
        "center": vector.vec3}


class Link(core.Struct):  # dtLink
    """r2recast/Detour/Include/DetourNavMesh.h:211"""
    neighbour: int  # 32-bit! not 64!
    next_link: int
    edge: int  # index of polygon edge owning this link
    boundary: List[int]  # side & sub-edge area; boundary links only
    flags: int

    _format = "2I4BI"
    __slots__ = ["neighbour", "next_link", "edge", "boundary", "flags"]
    _arrays = {"boundary": ["side", "min", "max"]}
    # TODO: flags enum


class DetailMesh(core.Struct):  # dtPolyDetail
    """r2recast/Detour/Include/DetourNavMesh.h:200"""
    _format = "2I2B"
    __slots__ = [
        "first_vertex", "first_triangle",
        "num_vertices", "num_triangles"]


class DetailTriangle(core.Struct):
    """Detour/Source/DetourNavMesh.cpp:644"""
    indices: List[int]
    # if index < poly.num_vertices: polygon.vertices[index]
    # else: polygon.detail_vertices[index - polygon.num_vertices]
    edge_flags: int  # 2:2:2 bitfield (top 2 bits unused)
    # ^ all correct values (1, 4, 16 & combinations thereof)

    _format = "4B"
    __slots__ = ["indices", "edge_flags"]
    _arrays = {"indices": 3}
    # TODO: flags enum / bitfield
    # TODO: enum: DT_DETAIL_EDGE_BOUNDARY etc.


class BoundsNode(core.Struct):  # dtBVNode
    """r2recast/Detour/Include/DetourNavMesh.h:225"""
    mins: List[int]
    maxs: List[int]
    index: int  # -ve for "escape sequence"

    _format = "6Hi"
    __slots__ = ["mins", "maxs", "index"]
    _arrays = {"mins": [*"xyz"], "maxs": [*"xyz"]}

    def __repr__(self) -> str:
        mins = f"({self.mins.x}, {self.mins.y}, {self.mins.y})"
        maxs = f"({self.maxs.x}, {self.maxs.y}, {self.maxs.y})"
        index = f"0x{self.index:08X}"
        return f"BoundsNode({mins}, {maxs}, {index})"


class Connection(core.Struct):  # dtOffMeshConnection
    """r2recast/Detour/Include/DetourNavMesh.h:234"""
    position: Tuple[vector.vec3, vector.vec3]
    radius: float
    polygon: int
    flags: int  # TODO: LinkFlags
    side: int  # endpoint side
    user_id: int
    reference_position: vector.vec3
    yaw_angle: float

    _format = "7fH2BI4f"
    __slots__ = [
        "position", "radius", "polygon", "flags", "side", "user_id",
        "reference_position", "yaw_angle"]
    _arrays = {"position": {"a": [*"xyz"], "b": [*"xyz"]}}
    _classes = {
        "position.a": vector.vec3,
        "position.b": vector.vec3,
        "reference_position": vector.vec3}


class Tile:  # dtMeshTile
    """r2recast/Detour/Source/DetourNavMesh.cpp:986"""
    header: TileHeader
    vertices: List[vector.vec3]
    polygons: List[Polygon]
    per_poly: List[bytes]  # per_poly_size
    links: List[Link]
    detail_meshes: List[DetailMesh]
    detail_vertices: List[vector.vec3]
    detail_triangles: List[DetailTriangle]
    bounds_tree: List[BoundsNode]
    connections: List[Connection]

    def __repr__(self) -> str:
        position = self.header.position
        pos = f"{position.x}.{position.y}.{position.layer}"
        return f"<Tile {pos} {len(self.polygons)} polygons>"

    def as_model(self) -> geometry.Model:
        # r2recast/DebugUtils/Source/DetourDebugDraw.cpp:49
        # r2recast/Detour/Source/DetourNavMesh.cpp:630
        normal = vector.vec3(z=+1)
        base_vertices = [
            geometry.Vertex(pos, normal, colour=(0, 0, 1, 1))
            for pos in self.vertices]
        polygons = [
            geometry.Polygon([
                base_vertices[i]
                for i in range(polygon.num_vertices)])
            for polygon in self.polygons]
        # detail mesh hell
        detail_vertices = [
            geometry.Vertex(pos, normal, colour=(0, 1, 0, 1))
            for pos in self.detail_vertices]
        polygons = list()
        assert len(self.polygons) == len(self.detail_meshes)
        for poly, dm in zip(self.polygons, self.detail_meshes):
            start = dm.first_triangle
            end = start + dm.num_triangles
            for triangle in self.detail_triangles[start:end]:
                face = list()
                for index in triangle.indices:
                    if index < poly.num_vertices:
                        face.append(base_vertices[index])
                    else:
                        index = dm.first_vertex + index - poly.num_vertices
                        if index > len(detail_vertices) or len(detail_vertices) == 0:
                            print(f"{poly=}")
                            vertex = geometry.Vertex(
                                poly.center,
                                normal,
                                colour=(1, 0, 0, 1))  # red
                            face.append(vertex)
                        else:
                            face.append(detail_vertices[index])
                assert len(face) == 3
                polygons.append(geometry.Polygon(face))
        return geometry.Model([geometry.Mesh(polygons=polygons)])

    @classmethod
    def from_bytes(cls, raw_tile: bytes) -> Tile:
        return cls.from_stream(io.BytesIO(raw_tile))

    @classmethod
    def from_stream(cls, stream: io.BytesIO) -> Tile:
        out = cls()
        # header
        out.header = TileHeader.from_stream(stream)
        assert out.header.magic == b"VAND", out.header.magic
        assert out.header.version == 13, out.header.version

        def align_4():
            stream.seek((4 - (stream.tell() % 4)) % 4, 1)

        # data
        out.vertices = [
            vector.vec3(*binary.read_struct(stream, "3f"))
            for i in range(out.header.num_vertices)]
        align_4()
        out.polygons = [
            Polygon.from_stream(stream)
            for i in range(out.header.num_polygons)]
        align_4()
        out.per_poly = [
            stream.read(out.header.per_poly_size * 4)
            for i in range(out.header.num_polygons)]
        align_4()
        out.links = [
            Link.from_stream(stream)
            for i in range(out.header.num_links)]
        align_4()
        out.detail_meshes = [
            DetailMesh.from_stream(stream)
            for i in range(out.header.detail.num_meshes)]
        align_4()
        out.detail_vertices = [
            vector.vec3(*binary.read_struct(stream, "3f"))
            for i in range(out.header.detail.num_vertices)]
        align_4()
        out.detail_triangles = [
            DetailTriangle.from_stream(stream)
            for i in range(out.header.detail.num_triangles)]
        # bleeding into bounds tree, bad counts?
        align_4()
        out.bounds_tree = [
            BoundsNode.from_stream(stream)
            for i in range(out.header.num_bounds_nodes)]
        align_4()
        out.connections = [
            Connection.from_stream(stream)
            for i in range(out.header.num_connections)]
        align_4()
        # NOTE: should've crashed by now if we ran out of data
        # -- but did we read all the data?
        out.tail = stream.read()
        if len(out.tail) > 0:
            position = out.header.position
            pos = f"{position.x}.{position.y}.{position.layer}"
            print(f"! TAIL @ {pos}")
        return out

    def as_bytes(self) -> bytes:
        out = [
            self.header.as_bytes(),
            *[struct.pack("3f", *vertex) for vertex in self.vertices],
            *[polygon.as_bytes() for polygon in self.polygons],
            *self.per_poly,
            *[link.as_bytes() for link in self.links],
            *[mesh.as_bytes() for mesh in self.detail_meshes],
            b"\x00\x00" if len(self.detail_meshes) % 2 == 1 else b"",  # pad
            *[struct.pack("3f", *vertex) for vertex in self.detail_vertices],
            *[tri.as_bytes() for tri in self.detail_triangles],
            *[node.as_bytes() for node in self.bounds_tree],
            *[conn.as_bytes() for conn in self.connections],
            self.tail]
        return b"".join(out)


class NavMesh(base.SceneDescription, breki.BinaryFile):
    """clockwise winding, right handed, Y up"""
    exts = ["*.nm"]
    header: FileHeader
    tiles: Dict[TilePos, TileHeader]
    # ^ {(x, y, layer): Tile}
    tile_refs: Dict[int, TilePos]
    # ^ {tileref: (x, y, layer)}

    def __init__(self, filepath: str, archive=None, code_page=None):
        super().__init__(filepath, archive, code_page)
        self.tiles = dict()
        self.tile_refs = dict()

    @parse_first
    def __repr__(self) -> str:
        descriptor = f'"{self.filename}" {len(self.tiles)} tiles'
        return f"<{self.__class__.__name__} {descriptor} @ 0x{id(self):016X}>"

    def tile_model(self, pos) -> geometry.Model:
        # NOTE: origin math is probably wrong, lots of assumptions
        # -- doesn't line up with geo well either
        tile = self.tiles[pos]
        x, y, layer = tile.header.position
        tile_size = self.header.params.tile_size
        x = x * tile_size.width
        y = y * tile_size.height
        # z = tile.position.layer *? +? ???
        tile_origin = vector.vec3(x, y)
        model = tile.as_model()
        # corrects wierd spikes, but messes up .usd layout
        # NOTE: wierd spikes occur on tiles w/ tailing data
        model = geometry.Model([
            geometry.Mesh(mesh.material, [
                geometry.Polygon([
                    geometry.Vertex(
                        vertex.position - tile_origin,
                        vertex.normal)
                    for vertex in polygon.vertices])
                for polygon in mesh.polygons])
            for mesh in model.meshes])
        model.origin = tile_origin  # + self.header.params.origin
        return model

    def parse(self):
        if self.is_parsed:
            return
        self.is_parsed = True
        self.header = FileHeader.from_stream(self.stream)
        assert self.header.magic == b"TESM", self.header.magic
        assert self.header.version == 5, self.header.version
        # tiles
        for i in range(self.header.num_tiles):
            tile_ref, data_size = binary.read_struct(self.stream, "2I")
            if 0 in (tile_ref, data_size):
                break
            raw_tile = self.stream.read(data_size)
            tile = Tile.from_bytes(raw_tile)
            tile_pos = tile.header.position
            assert tile_ref not in self.tile_refs
            assert tile_pos not in self.tiles
            self.tile_refs[tile_ref] = tile_pos
            self.tiles[tile_pos] = tile
        # NOTE: there's still some data after this point
        # -- I ain't parsing all that
        self.tail = self.stream.read()
        # tiles -> models
        self.models = {
            f"Tile.{pos.x}.{pos.y}.{ref:08X}": self.tile_model(pos)
            for ref, pos in self.tile_refs.items()}
