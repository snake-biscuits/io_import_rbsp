from . import base


class Nightfire007(base.Archive):
    ext = "*.007"

    def __init__(self, filename: str):
        raise NotImplementedError()
