"""Raven Software worked closely with Id Software
They were later acquired by Activision
After this acquisition, many devs left to found Human Head Studios
Raven has also worked on a number of recent Call of Duty titles (~2010-present)"""
# TODO: notes on Dreamcast SoF port (Mort the Chicken publisher)
from . import hexen2
from . import soldier_of_fortune
from . import soldier_of_fortune2


scripts = [hexen2, soldier_of_fortune, soldier_of_fortune2]
