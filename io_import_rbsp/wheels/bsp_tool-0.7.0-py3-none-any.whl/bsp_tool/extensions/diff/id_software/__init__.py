__all__ = ["quake2"]

from . import quake2
