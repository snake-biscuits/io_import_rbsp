"""Creators of Maerchen Busters"""
from . import merubasu


scripts = [merubasu]
