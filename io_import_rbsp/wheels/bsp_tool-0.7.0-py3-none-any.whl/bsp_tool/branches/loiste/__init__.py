"""Loiste Interactive are the small development team behind Infra.
Development began in 2011, similarly to Respawn's Titanfall."""
from . import infra

scripts = [infra]
