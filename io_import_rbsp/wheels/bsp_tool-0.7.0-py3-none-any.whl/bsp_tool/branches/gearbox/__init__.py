"""Gearbox's second Half-Life expansion: Blue Shift made a few changes to the GoldSrc engine."""
from . import blue_shift
from . import nightfire


scripts = [blue_shift, nightfire]
