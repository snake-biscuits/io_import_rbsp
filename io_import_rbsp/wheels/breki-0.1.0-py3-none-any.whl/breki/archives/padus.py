"""Padus, Inc. DiscJuggler .cdi format"""
# https://en.wikipedia.org/wiki/DiscJuggler
# https://github.com/jozip/cdirip
from __future__ import annotations
import io

from .. import binary
from .. import files
from . import base


def parse_track(stream: io.BytesIO, cdi_version: int, name: str) -> (base.Track, int):
    """returns Track & pregap_size (length in bytes)"""

    def skip(length: int):
        stream.seek(length, 1)

    # cdi.c:ask_type
    tmp = binary.read_struct(stream, "I")
    if tmp != 0:
        skip(8)  # DiscJuggler 3.00.780+
    assert stream.read(20) == b"\x00\x00\x01\x00\x00\x00\xFF\xFF\xFF\xFF" * 2, "no track start marker"
    skip(4)
    filename_length = binary.read_struct(stream, "B")
    # filename = stream.read(filename_length).decode()  # .cdi filename
    skip(filename_length)
    skip(19)  # 11 + 4 + 4
    tmp = binary.read_struct(stream, "I")
    if tmp == 0x80000000:
        skip(8)  # DiscJuggler 4
    skip(2)
    pregap_length, length = binary.read_struct(stream, "2i")
    # NOTE: pregap_length is almost always 150
    if length == 0:  # data is in pregap
        length = pregap_length
        pregap_length = 0
    skip(6)
    mode = base.TrackMode(binary.read_struct(stream, "I"))
    skip(12)
    start_lba, total_length = binary.read_struct(stream, "Ii")
    assert total_length == pregap_length + length
    skip(16)
    sector_size_index = binary.read_struct(stream, "I")
    sector_size = [2048, 2336, 2352][sector_size_index]
    skip(29)
    if cdi_version != "2.0":
        skip(5)
        tmp = binary.read_struct(stream, "I")
        if tmp == 0xFFFFFFFF:
            skip(78)  # DiscJuggler 3.00.780+
    track = base.Track(mode, sector_size, start_lba, length, name)
    return track, pregap_length * sector_size


class Cdi(base.DiscImage, files.BinaryFile):
    exts = ["*.cdi"]
    version: str  # e.g. "2.0"

    def __repr__(self) -> str:
        descriptor = " ".join([
            f"v{self.version}",
            f"{len(self)} sectors",
            f"({len(self.tracks)} tracks)"])
        return f"<{self.__class__.__name__} {descriptor} @ 0x{id(self):016X}>"

    def parse(self):
        self.is_parsed = True
        # version identifier
        self.stream.seek(0, 2)  # "header" is on the tail
        length = self.stream.tell()
        assert length > 8
        self.stream.seek(-8, 2)
        version, header_offset = binary.read_struct(self.stream, "2I")
        version_code = {
            0x80000004: "2.0",
            0x80000005: "3.0",
            0x80000006: "3.5"}
        assert version in version_code, "unknown .cdi format version"
        assert header_offset != 0, "invalid .cdi file"
        self.version = version_code[version]
        if self.version != "3.5":
            self.stream.seek(header_offset)
        else:  # v3.0 header_offset is negative
            self.stream.seek(length - header_offset)
        # the "header"
        needle = 0  # track offsets
        track_offsets = list()
        num_sessions = binary.read_struct(self.stream, "H")
        for session in range(num_sessions):
            num_tracks = binary.read_struct(self.stream, "H")
            # NOTE: some sessions have 0 tracks
            for track in range(num_tracks):
                name = f"Session {session + 1:02d} Track {track + 1:02d}"
                track, pregap_length = parse_track(self.stream, self.version, name)
                self.tracks.append(track)
                track_offsets.append(needle + pregap_length)
                needle += pregap_length + (track.length * track.sector_size)
            # cdi.c:CDI_skip_next_session
            self.stream.seek(12, 1)  # 4 + 8
            if self.version != "2.0":
                self.stream.seek(1, 1)
        # get track data
        for track, offset in zip(self.tracks, track_offsets):
            self.stream.seek(offset)
            length = track.length * track.sector_size
            data = self.stream.read(length)
            assert len(data) == length
            self.friends[track.name] = files.File.from_bytes(track.name, data)
