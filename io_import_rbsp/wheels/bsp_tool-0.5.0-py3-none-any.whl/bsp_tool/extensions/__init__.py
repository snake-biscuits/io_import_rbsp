"""To use an extension you must import it directly:
from bsp_tool.extensions import extension
extension.function(...)"""
