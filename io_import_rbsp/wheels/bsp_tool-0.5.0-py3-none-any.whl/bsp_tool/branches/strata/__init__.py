"""https://stratasource.github.io/Wiki/"""
from . import strata


scripts = [strata]
