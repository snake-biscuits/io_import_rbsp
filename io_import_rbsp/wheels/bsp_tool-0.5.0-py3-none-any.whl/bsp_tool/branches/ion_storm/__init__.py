"""John Romero & others broke away from Id Software early in Quake 2 development"""
from . import daikatana


scripts = [daikatana]
