"""Creators of Zeno Clash"""
from . import zeno_clash


scripts = [zeno_clash]
