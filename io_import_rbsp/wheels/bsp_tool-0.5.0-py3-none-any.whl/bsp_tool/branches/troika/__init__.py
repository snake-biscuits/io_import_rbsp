"""Creators of Vampire: The Masquerade - Bloodlines"""
from . import vampire


scripts = [vampire]
