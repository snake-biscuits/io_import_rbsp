"""WildTangent's Genesis3D Engine"""
# https://en.wikipedia.org/wiki/WildTangent#Genesis3D
# https://www.mobygames.com/group/7425/3d-engine-genesis3d/
from . import genesis3d


scripts = [genesis3d]
