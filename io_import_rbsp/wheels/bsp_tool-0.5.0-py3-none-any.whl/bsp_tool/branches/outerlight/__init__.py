"""Creators of The Ship & Bloody Good Time"""
from . import outerlight


scripts = [outerlight]
